require "octovy/test/version"

module Octovy
  module Test
    class Error < StandardError; end
    # Your code goes here...
  end
end
