module Octovy
  module Test
    VERSION = "0.1.0"
  end
end
